"""Lokale Sprachausgabe für Diction (mlx-audio, z. B. Voxtral).

Läuft als Kindprozess von Diction. Eine JSON-Zeile je Nachricht:

stdin:  {"id": 1, "voice": "de_female", "segments": ["Satz eins.", "Satz zwei."]}
        {"cancel": 1}
stdout: {"ready": true, "sample_rate": 24000}
        {"id": 1, "segment": 0, "audio": "<base64, 16-Bit-PCM mono>"}
        {"id": 1, "segment": 0, "done": true}
        {"id": 1, "finished": true}  bzw.  {"id": 1, "error": "…"}

Endet, sobald stdin geschlossen wird (Diction beendet oder abgestürzt).
"""
import base64
import json
import os
import queue
import sys
import threading

# Bibliotheken schreiben gern auf stdout (Ladebalken, Hinweise). Das Protokoll bekommt eine eigene Kopie
# des Kanals, alles andere landet auf stderr.
_protocol = os.fdopen(os.dup(1), "w", buffering=1)
os.dup2(2, 1)
sys.stdout = sys.stderr

import numpy as np  # noqa: E402

_out = threading.Lock()


def send(message):
    line = json.dumps(message) + "\n"
    with _out:
        _protocol.write(line)
        _protocol.flush()


def pcm16(audio):
    samples = np.clip(np.asarray(audio, dtype=np.float32).reshape(-1), -1, 1)
    return base64.b64encode((samples * 32767).astype("<i2").tobytes()).decode()


def main():
    model_id = sys.argv[1]
    from mlx_audio.tts.utils import load_model

    model = load_model(model_id)
    # Einmal kurz rechnen, damit der erste echte Satz nicht auf das Kompilieren wartet.
    for _ in model.generate(text="Hallo."):
        pass
    send({"ready": True, "sample_rate": model.sample_rate})

    requests = queue.Queue()
    cancelled = set()

    def read():
        for line in sys.stdin:
            try:
                message = json.loads(line)
            except ValueError:
                continue
            if "cancel" in message:
                cancelled.add(message["cancel"])
            else:
                requests.put(message)
        requests.put(None)

    threading.Thread(target=read, daemon=True).start()

    while (request := requests.get()) is not None:
        rid = request["id"]
        options = {"voice": request["voice"]} if request.get("voice") else {}
        try:
            for index, text in enumerate(request["segments"]):
                for result in model.generate(text=text, stream=True, streaming_interval=0.5, **options):
                    if rid in cancelled:
                        break
                    send({"id": rid, "segment": index, "audio": pcm16(result.audio)})
                if rid in cancelled:
                    break
                send({"id": rid, "segment": index, "done": True})
            send({"id": rid, "finished": True})
        except Exception as error:  # noqa: BLE001 – jeder Fehler geht als Meldung an Diction
            send({"id": rid, "error": f"{type(error).__name__}: {error}"})
        cancelled.discard(rid)


if __name__ == "__main__":
    main()
