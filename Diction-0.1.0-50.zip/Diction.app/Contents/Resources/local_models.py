"""Modellverwaltung für Diction: Hugging-Face-Cache auflisten, Modelle laden und löschen.

Der Cache teilt Dateien zwischen Modellen (Xet), deshalb rechnet und löscht nur huggingface_hub selbst richtig.

  local_models.py list            →  {"models": [{"id": "org/name", "size": 123}]}
  local_models.py download <id>   →  {"done": 1, "total": 2} … {"finished": true}
  local_models.py delete <id>     →  {"freed": 123}
Fehler: {"error": "…"}
"""
import json
import os
import sys
import time

_protocol = os.fdopen(os.dup(1), "w", buffering=1)
os.dup2(2, 1)
sys.stdout = sys.stderr


def send(message):
    _protocol.write(json.dumps(message) + "\n")
    _protocol.flush()


def list_models():
    from huggingface_hub import scan_cache_dir

    repos = [r for r in scan_cache_dir().repos if r.repo_type == "model"]
    send({"models": [{"id": r.repo_id, "size": r.size_on_disk} for r in repos]})


def download(repo_id):
    from huggingface_hub import snapshot_download
    from tqdm import tqdm

    last = [0.0]
    bars = {}

    class Progress(tqdm):
        """Meldet den Byte-Fortschritt des ganzen Downloads als JSON-Zeilen.

        huggingface_hub führt zwei Balken: „Downloading bytes“ (Netz, laufend) und „Reconstructing“
        (auf Platte, oft erst am Ende jeder Datei, aber mit der echten Gesamtgröße). Gemeldet wird der weitere.
        """

        def __init__(self, *args, **kwargs):
            kwargs["file"] = open(os.devnull, "w")
            super().__init__(*args, **kwargs)
            desc = str(kwargs.get("desc", ""))
            for kind in ("Reconstruct", "Downloading bytes"):
                if desc.startswith(kind):
                    bars[kind] = self

        def update(self, n=1):
            result = super().update(n)
            now = time.monotonic()
            reconstruct = bars.get("Reconstruct")
            if self in bars.values() and reconstruct is not None and reconstruct.total and now - last[0] > 0.25:
                last[0] = now
                done = max(bar.n for bar in bars.values())
                send({"done": min(done, reconstruct.total), "total": reconstruct.total})
            return result

    snapshot_download(repo_id, tqdm_class=Progress)
    send({"finished": True})


def delete(repo_id):
    from huggingface_hub import scan_cache_dir

    cache = scan_cache_dir()
    revisions = [rev.commit_hash for r in cache.repos if r.repo_id == repo_id for rev in r.revisions]
    strategy = cache.delete_revisions(*revisions)
    strategy.execute()
    send({"freed": strategy.expected_freed_size})


def main():
    command, *args = sys.argv[1:]
    try:
        {"list": list_models, "download": download, "delete": delete}[command](*args)
    except Exception as error:  # noqa: BLE001 – jeder Fehler geht als Meldung an Diction
        send({"error": f"{type(error).__name__}: {error}"})
        sys.exit(1)


if __name__ == "__main__":
    main()
