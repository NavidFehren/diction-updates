"""Lokale Transkription für Diction (mlx-audio: Cohere Transcribe, Parakeet, Whisper …). Protokoll: siehe local_worker.py.

Anfrage:  {"id": 1, "audio": "/pfad/aufnahme.wav", "language": "de" | null, "terms": ["Diction", …]}
Antwort:  {"ready": true}
          {"id": 1, "text": "…", "language": "de"}
"""
import inspect
import os
import sys
import wave

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # local_worker liegt daneben im App-Bundle
from local_worker import send, serve  # noqa: E402 – muss vor allen anderen Imports laufen

# Ab dieser Länge in Stücken rechnen, sonst braucht Parakeet bei langen Dateien sehr viel Speicher.
CHUNK_SECONDS = 120


def duration(path):
    try:
        with wave.open(path) as audio:
            return audio.getnframes() / audio.getframerate()
    except (wave.Error, OSError):
        return 0


def main():
    from mlx_audio.stt import load

    model = load(sys.argv[1])
    parameters = inspect.signature(model.generate).parameters
    # Modelle mit festem Standard (Cohere: "en") erkennen die Sprache nicht selbst.
    language_parameter = parameters.get("language")
    needs_language = language_parameter is not None and language_parameter.default not in (None, inspect.Parameter.empty)

    def options(request):
        result = {}
        language = request.get("language")
        if language_parameter is not None:
            if language:
                result["language"] = language
            elif needs_language:
                result["language"] = "de"
        if request.get("terms") and "hotwords" in parameters:
            result["hotwords"] = request["terms"]
        if "chunk_duration" in parameters and "initial_prompt" not in parameters:
            if duration(request["audio"]) > CHUNK_SECONDS:
                result["chunk_duration"] = CHUNK_SECONDS
        return result

    # Einmal eine Sekunde Stille rechnen, damit das erste Diktat nicht auf das Kompilieren wartet.
    silence = os.path.join(os.environ.get("TMPDIR", "/tmp"), f"diction-warmup-{os.getpid()}.wav")
    with wave.open(silence, "wb") as audio:
        audio.setnchannels(1)
        audio.setsampwidth(2)
        audio.setframerate(16000)
        audio.writeframes(b"\0\0" * 16000)
    try:
        model.generate(silence, **options({"audio": silence}))
    finally:
        os.remove(silence)

    def handle(request, cancelled):
        settings = options(request)
        output = model.generate(request["audio"], **settings)
        text = (getattr(output, "text", None) or "").strip()
        language = getattr(output, "language", None) or settings.get("language")
        if isinstance(language, list):
            language = language[0] if language else None
        send({"id": request["id"], "text": text, "language": language})

    serve(handle)


if __name__ == "__main__":
    main()
