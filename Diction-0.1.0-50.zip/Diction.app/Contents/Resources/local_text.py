"""Lokales Sprachmodell für Diction (mlx-lm: Gemma, Qwen …). Protokoll: siehe local_worker.py.

Anfrage:  {"id": 1, "system": "…" | null, "prompt": "…", "max_tokens": 4096}
Antwort:  {"ready": true}
          {"id": 1, "text": "Stück"}   beliebig oft, aneinandergehängt ergibt das die Antwort
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # local_worker liegt daneben im App-Bundle
from local_worker import send, serve  # noqa: E402 – muss vor allen anderen Imports laufen

# Text bearbeiten verlangt Treue zur Vorlage, keine Kreativität.
TEMPERATURE = 0.3
TOP_P = 0.95


def main():
    from mlx_lm import load, stream_generate
    from mlx_lm.sample_utils import make_sampler

    model, tokenizer = load(sys.argv[1])
    sampler = make_sampler(temp=TEMPERATURE, top_p=TOP_P)

    def prompt(request):
        messages = [{"role": "user", "content": request["prompt"]}]
        if request.get("system"):
            messages.insert(0, {"role": "system", "content": request["system"]})
        # Denkmodus aus: Diction will nur das Ergebnis, und das schnell. Vorlagen ohne den Schalter ignorieren ihn.
        return tokenizer.apply_chat_template(messages, add_generation_prompt=True, enable_thinking=False)

    # Einmal kurz rechnen, damit die erste echte Anfrage nicht auf das Kompilieren wartet.
    for _ in stream_generate(model, tokenizer, prompt({"prompt": "Hallo"}), max_tokens=1, sampler=sampler):
        pass

    def handle(request, cancelled):
        for response in stream_generate(model, tokenizer, prompt(request),
                                        max_tokens=request.get("max_tokens") or 4096, sampler=sampler):
            if cancelled():
                return
            if response.text:
                send({"id": request["id"], "text": response.text})

    serve(handle)


if __name__ == "__main__":
    main()
