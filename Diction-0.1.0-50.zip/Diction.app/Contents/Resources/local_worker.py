"""Gemeinsames Protokoll der lokalen Kindprozesse von Diction (Vorlesen, Transkription, Text).

Eine JSON-Zeile je Nachricht:

stdin:  {"id": 1, …Anfrage…}
        {"cancel": 1}
stdout: {"ready": true, …}                  einmal, sobald das Modell geladen ist
        {"id": 1, …Zwischenergebnis…}       beliebig oft
        {"id": 1, "finished": true}  bzw.  {"id": 1, "error": "…"}

Der Prozess endet, sobald stdin geschlossen wird (Diction beendet oder abgestürzt).
"""
import json
import os
import queue
import sys
import threading

# Bibliotheken schreiben gern auf stdout (Ladebalken, Hinweise). Das Protokoll bekommt eine eigene Kopie
# des Kanals, alles andere landet auf stderr. Muss vor allen anderen Imports passieren.
_protocol = os.fdopen(os.dup(1), "w", buffering=1)
os.dup2(2, 1)
sys.stdout = sys.stderr

_out = threading.Lock()


def send(message):
    line = json.dumps(message) + "\n"
    with _out:
        _protocol.write(line)
        _protocol.flush()


def serve(handle, ready=None):
    """Meldet Bereitschaft und bearbeitet Anfragen nacheinander, bis stdin endet.

    `handle(request, cancelled)` schickt Zwischenergebnisse selbst mit `send` (samt `id`) und prüft
    zwischendurch `cancelled()`. Abschluss- und Fehlermeldung übernimmt `serve`.
    """
    send({"ready": True, **(ready or {})})

    requests = queue.Queue()
    cancelled = set()

    def read():
        for line in sys.stdin:
            try:
                message = json.loads(line)
            except ValueError:
                continue
            if "cancel" in message:
                cancelled.add(message["cancel"])
            else:
                requests.put(message)
        requests.put(None)

    threading.Thread(target=read, daemon=True).start()

    while (request := requests.get()) is not None:
        rid = request["id"]
        try:
            handle(request, lambda: rid in cancelled)
            send({"id": rid, "finished": True})
        except Exception as error:  # noqa: BLE001 – jeder Fehler geht als Meldung an Diction
            send({"id": rid, "error": f"{type(error).__name__}: {error}"})
        cancelled.discard(rid)
