"""Lokale Sprachausgabe für Diction (mlx-audio, z. B. Voxtral). Protokoll: siehe local_worker.py.

Anfrage:  {"id": 1, "voice": "de_female", "segments": ["Satz eins.", "Satz zwei."]}
Antwort:  {"ready": true, "sample_rate": 24000}
          {"id": 1, "segment": 0, "audio": "<base64, 16-Bit-PCM mono>"}
          {"id": 1, "segment": 0, "done": true}
"""
import base64
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # local_worker liegt daneben im App-Bundle
from local_worker import send, serve  # noqa: E402 – muss vor allen anderen Imports laufen

import numpy as np  # noqa: E402


def pcm16(audio):
    samples = np.clip(np.asarray(audio, dtype=np.float32).reshape(-1), -1, 1)
    return base64.b64encode((samples * 32767).astype("<i2").tobytes()).decode()


def main():
    from mlx_audio.tts.utils import load_model

    model = load_model(sys.argv[1])
    # Einmal kurz rechnen, damit der erste echte Satz nicht auf das Kompilieren wartet.
    for _ in model.generate(text="Hallo."):
        pass

    def handle(request, cancelled):
        rid = request["id"]
        options = {"voice": request["voice"]} if request.get("voice") else {}
        for index, text in enumerate(request["segments"]):
            for result in model.generate(text=text, stream=True, streaming_interval=0.5, **options):
                if cancelled():
                    return
                send({"id": rid, "segment": index, "audio": pcm16(result.audio)})
            send({"id": rid, "segment": index, "done": True})

    serve(handle, {"sample_rate": model.sample_rate})


if __name__ == "__main__":
    main()
